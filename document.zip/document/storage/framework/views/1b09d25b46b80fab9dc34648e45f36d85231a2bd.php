<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <script src="<?php echo asset('js/jquery-1.11.3.min.js'); ?>"></script>
        <link href="<?php echo asset('bootstrap/css/bootstrap.css'); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo asset('css/category.css'); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo asset('datepicker/css/datepicker.css'); ?>" rel="stylesheet" type="text/css">
        <script src="<?php echo asset('bootstrap/js/bootstrap.js'); ?>"></script>
        <script src="<?php echo asset('datepicker/js/bootstrap-datepicker.js'); ?>"></script>

    </head>
    <body>
        <div class="container">
            <div class="">
                <h1>Transactions management</h1>
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php foreach($errors->all() as $error): ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <hr>
                <a href="<?php echo url('transactions'); ?>">
                    Index Transactions
                </a>
                <hr>
                <form class="form-signin" method="post" action="/monthtransaction">
                    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                    <div class="form-group">
                        <label for="exampleInputName">Select Month Transaction</label>
                        <br>
<!--                        <div class="input-append date" id="dpMonths" data-date="102/2012" data-date-format="mm/yyyy" data-date-viewmode="months" data-date-minviewmode="years">
                            <input name="month" class="span2" size="16" type="text" value="02/2012" readonly="">
				<span class="add-on"><i class="icon-calendar"></i></span>
			</div>-->
                        <input name="month" class="datepicker" data-date="102/2012" data-date-format="mm/yyyy" data-date-viewmode="months" data-date-minviewmode="years"/>
                        <script>
                            $('.datepicker').datepicker();
                        </script>
                    </div>
                    <button type="submit" class="btn btn-default">Report Transaction</button>
                </form><!-- /form -->
                <hr>
                <?php foreach($transmoneys as $var): ?>
                <div class="wallet">
                    <hr>
                    <img id="profile-img" class="profile-img-card" src="<?php echo $var->image; ?>" />
                    <div class="form-group">
                        <label for="exampCategory">Name Transactions:</label>
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $var->name; ?>

                    </div>
                    <div class="form-group">
                        <label for="exampCategory">Note:</label>
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $var->note; ?>

                    </div>
                    <div class="form-group">
                        <label for="exampCategory">Money</label>
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $var->money; ?> &nbsp;<?php echo $var->type_money; ?>

                    </div>
                    <div class="form-group">
                        <label for="exampCategory">Action:</label>
                        <br>
                        &nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo url('updatetransaction'); ?>/<?php echo $var->id; ?>">
                            <span class="glyphicon glyphicon-edit" aria-hidden="true"></span>
                        </a>&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo url('deletetransaction'); ?>/<?php echo $var->id; ?>">
                            <span class="glyphicon glyphicon-remove" aria-hidden="true"></span>
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
                <hr>
            </div><!-- /card-container -->
        </div><!-- /container -->
    </body>
</html>
