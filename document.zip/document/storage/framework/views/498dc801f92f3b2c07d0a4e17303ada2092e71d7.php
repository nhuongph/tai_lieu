<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Money love - Manager you money</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- Font Awesome CSS -->
        <link href="<?php echo e(asset('layouts/css/font-awesome.min.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('layouts/css/animate.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('layouts/css/style.css')); ?>" rel="stylesheet">

        <!-- NhuongPH CSS -->
        <link href="<?php echo e(asset('layouts/css/mycss.css')); ?>" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href='<?php echo e(asset('layouts/css/font-Lobster.css')); ?>' rel='stylesheet' type='text/css'>


        <!-- Template js -->
        <script src="<?php echo e(asset('layouts/js/jquery-2.1.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/jquery.appear.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/jqBootstrapValidation.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/modernizr.custom.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/script.js')); ?>"></script>

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>

        <!-- Start Logo Section -->
        <section id="logo-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logo text-center">
                            <h1>Money Lover</h1>
                            <span>Manager You Money</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="logo-right container">
                <?php if (Auth::check()) { ?>
                    <?php echo e(trans('home.welcome',['name' => Auth::user()->username])); ?> | <a href="<?php echo url('welcome/vi'); ?>">Việt Nam</a> &nbsp;<a href="<?php echo url('welcome/en'); ?>">English</a> | <a href="<?php echo url('logout'); ?>">Logout</a>
                <?php } ?>
            </div>
        </section>
        <!-- End Logo Section -->


        <!-- Start Main Body Section -->
        <div class="mainbody-section text-center">
            <div class="container">
                <div class="row">

                    <div class="col-md-3">

                        <div class="menu-item light-red">
                            <a href="<?php echo url('home'); ?>" data-toggle="modal">
                                <i class="fa fa-user"></i>
                                <p>Home</p>
                            </a>
                        </div>

                        <div class="menu-item green">
                            <a href="<?php echo url('wallet'); ?>" data-toggle="modal">
                                <i class="fa fa fa-money"></i>
                                <p>All Wallet</p>
                            </a>
                        </div>

                        <div class="menu-item blue">
                            <a href="<?php echo url('addwallet'); ?>" data-toggle="modal">
                                <i class="glyphicon glyphicon-star-empty"></i>
                                <p>New Wallet</p>
                            </a>
                        </div>

                    </div>

                    <div class="col-md-9 bg-white padding-top-bot col-md-offset-0">

                        <h1>Transfer money between Wallets!</h1>
                        <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php foreach($errors->all() as $error): ?>
                                <li><?php echo e($error); ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <?php if(Session::has('message')): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <li><?php echo session('message'); ?></li>
                            </ul>
                        </div>
                        <?php endif; ?>
                        <?php echo Form::open(array('url' => 'transwallet','class'=>'form-signin')); ?>

                        <div class="wallet">
                            <img id="profile-img" class="profile-img-card" src="<?php echo url($wallet->image); ?>" />
                            <table>
                                <tr><th>Name of Wallet:</th><td><?php echo $wallet->name; ?></td></tr>
                                <tr><th>Money in Wallet:</th><td><?php echo $wallet->money; ?>&nbsp;<?php echo $wallet->type_money; ?></td></tr>
                                <tr><th>Note of Wallet:</th><td><?php echo $wallet->note; ?></td></tr>     
                            </table>
                            <?php echo Form::hidden('id', $wallet->id); ?>

                        </div>
                        <div class="chose_wallet"> 
                            <table class="table table-hover">
                                <hr>
                                <div class="col-md-8 col-md-offset-2">
                                    <h2>Transfer money</h2>
                                    <div class="form-group">
                                        <?php echo Form::label('select_wallet','Select Wallet for transfer:'); ?>

                                        <?php echo Form::select('select_wallet', $wallets, null, ['class' => 'form-control']); ?>

                                    </div>
                                    <div class="form-group">
                                        <?php echo Form::label('trans_money','Input money:'); ?>

                                        <?php echo Form::text('trans_money',null, array('class'=>'form-control')); ?>

                                    </div>
                                    <?php echo Form::submit('Transfer Money',['class' => 'btn btn-success']); ?>


                                </div>
                            </table>
                        </div>
                        <?php echo Form::close(); ?><!-- /form -->
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- End Main Body Section -->
</body>

</html>