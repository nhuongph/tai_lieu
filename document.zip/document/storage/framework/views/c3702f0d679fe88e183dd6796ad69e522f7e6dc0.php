<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">

        <title>Money love - Manager you money</title>

        <!-- Bootstrap Core CSS -->
        <link href="<?php echo e(asset('bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

        <!-- Font Awesome CSS -->
        <link href="<?php echo e(asset('layouts/css/font-awesome.min.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('layouts/css/animate.css')); ?>" rel="stylesheet">

        <!-- Custom CSS -->
        <link href="<?php echo e(asset('layouts/css/style.css')); ?>" rel="stylesheet">

        <!-- NhuongPH CSS -->
        <link href="<?php echo e(asset('layouts/css/mycss.css')); ?>" rel="stylesheet">

        <!-- Custom Fonts -->
        <link href='<?php echo e(asset('layouts/css/font-Lobster.css')); ?>' rel='stylesheet' type='text/css'>


        <!-- Template js -->
        <script src="<?php echo e(asset('layouts/js/jquery-2.1.1.min.js')); ?>"></script>
        <script src="<?php echo e(asset('bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/jquery.appear.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/jqBootstrapValidation.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/modernizr.custom.js')); ?>"></script>
        <script src="<?php echo e(asset('layouts/js/script.js')); ?>"></script>

        <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->

    </head>

    <body>

        <!-- Start Logo Section -->
        <section id="logo-section">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="logo text-center">
                            <h1>Money Lover</h1>
                            <span>Manager You Money</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="logo-right container">
                <?php if (Auth::check()) { ?>
                    <?php echo e(trans('home.welcome',['name' => Auth::user()->username])); ?> | <a href="<?php echo url('welcome/vi'); ?>">Việt Nam</a> &nbsp;<a href="<?php echo url('welcome/en'); ?>">English</a> | <a href="<?php echo url('logout'); ?>">Logout</a>
                <?php } ?>
            </div>
        </section>
        <!-- End Logo Section -->


        <!-- Start Main Body Section -->
        <div class="mainbody-section text-center">
            <div class="container">
                <div class="row">

                    <div class="col-md-3">

                        <div class="menu-item light-red">
                            <a href="<?php echo url('home'); ?>" data-toggle="modal">
                                <i class="fa fa-user"></i>
                                <p>Home</p>
                            </a>
                        </div>

                        <div class="menu-item color responsive">
                            <a href="<?php echo url('category'); ?>" data-toggle="modal">
                                <i class="glyphicon glyphicon-th-list"></i>
                                <p>All Categories</p>
                            </a>
                        </div>

                    </div>

                    <div class="col-md-9 bg-white padding-top-bot col-md-offset-0">
                        <div class="col-md-8 col-md-offset-2">
                            <h1>New Category</h1>
                            <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php foreach($errors->all() as $error): ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php if(Session::has('message')): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <li><?php echo session('message'); ?></li>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <?php echo Form::open(array('url' => 'addcategory', 'files' => true, 'class'=>'form-signin')); ?>

                            <div class="form-group">
                                <?php echo Form::text('name',null, array('class'=>'form-control','placeholder'=>'Name category')); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::textarea('note',null, array('class'=>'form-control','placeholder'=>'Note...')); ?>

                            </div>
                            <div class="form-group">
                                <?php echo Form::label('image','Select avatar for Categories'); ?>

                                <?php echo Form::file('image',['class'=>"btn btn-default btn-file form-control"]); ?>

                                <p class="help-block">Avartar help your easy select Categories.</p>
                            </div>
                            <?php echo Form::submit('New Category',['class' => 'btn btn-success']); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- End Main Body Section -->
</body>

</html>