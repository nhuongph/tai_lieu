<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        <script src="<?php echo asset('js/jquery-1.11.3.min.js'); ?>"></script>
        <link href="<?php echo asset('bootstrap/css/bootstrap.css'); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo asset('css/category.css'); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo asset('datepicker/css/datepicker.css'); ?>" rel="stylesheet" type="text/css">
        <script src="<?php echo asset('bootstrap/js/bootstrap.js'); ?>"></script>        
        <link href="<?php echo asset('css/mycss.css'); ?>" rel="stylesheet" type="text/css">
        <script src="<?php echo asset('datepicker/js/bootstrap-datepicker.js'); ?>"></script>

    </head>
    <body>
        <div class="container">
            <div class="">
                <h1>Search Transactions management</h1>
                <hr>

                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <!-- Brand and toggle get grouped for better mobile display -->
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand" href="<?php echo url('home'); ?>">Money Lover</a>
                        </div>

                        <!-- Collect the nav links, forms, and other content for toggling -->
                        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                            <ul class="nav navbar-nav">
                                <li class="dropdown">
                                    <a href="<?php echo url('home'); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Wallets <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="<?php echo url('home'); ?>">All Wallets</a></li>
                                        <li><a href="<?php echo url('addwallet'); ?>">New Wallet</a></li>                              
                                    </ul>
                                </li>
                                <li class="dropdown">
                                    <a href="<?php echo url('category'); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Categories <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="<?php echo url('category'); ?>">All Wallets</a></li>     
                                        <li><a href="<?php echo url('addcategory'); ?>">New Categories</a></li>                              
                                    </ul>
                                </li>
                                <li class="dropdown active">
                                    <a href="<?php echo url('transactions'); ?>" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Transactions Money <span class="caret"></span></a>
                                    <ul class="dropdown-menu">
                                        <li><a href="<?php echo url('transactions'); ?>">All Transactions</a></li>    
                                        <li><a href="<?php echo url('addtransaction'); ?>">New Transaction</a></li> 
                                        <li><a href="<?php echo url('seachreport'); ?>">Search Transactions</a></li>    
                                        <li><a href="<?php echo url('reportmonth'); ?>">Report Month</a></li>   
                                    </ul>
                                </li>
                            </ul>
                            <ul class="nav navbar-nav navbar-right">
                                <li><a href="<?php echo url('update'); ?>/<?php echo Auth::user()->username; ?>">Update user</a></li>
                                <li><a href="<?php echo url('logout'); ?>">Logout</a></li>
                            </ul>
                        </div><!-- /.navbar-collapse -->
                    </div><!-- /.container-fluid -->
                </nav>
                <!--*******************-->
                <hr>
                <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php foreach($errors->all() as $error): ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
                <?php echo Form::open(array('url' => 'seachreport','class'=>'form-signin col-md-5')); ?>

                <div class="trans-search">
                    <div class="form-group">
                        <?php echo Form::label('date_search','Select Month Transaction:'); ?>

                        <?php echo Form::text('date_search',null, array('class'=>'datepicker form-control', 'data-date' => '102/2012' ,'data-date-format' => 'dd/mm/yyyy')); ?>

                        <script>
                            $('.datepicker').datepicker();
                        </script>
                    </div>
                    <div class="form-group">
                        <?php echo Form::label('category_id','Category Transaction:'); ?>

                        <?php echo Form::select('category_id', $categories, null, ['class' => 'form-control']); ?>

                    </div>
                    <?php echo Form::submit('Search Transaction',['class' => 'btn btn-success']); ?>

                    <?php echo Form::close(); ?>

                </div>
                <hr>
                <?php foreach($transmoneys as $var): ?>
                <div class="trans">
                    <hr>
                    <img id="profile-img" class="profile-img-card" src="<?php echo $var->image; ?>" />
                    <table class="trans-right"
                           <tr><th>
                                <?php echo Form::label('category_id','Name Transactions:'); ?>

                            </th><td>
                                &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $var->name; ?>

                            </td></tr>
                        <tr><th>
                                <?php echo Form::label('note','Note:'); ?>

                            </th><td>
                                &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $var->note; ?>

                            </td></tr>
                        <tr><th>
                                <?php echo Form::label('money','Money:'); ?>

                            </th><td>
                                &nbsp;&nbsp;&nbsp;&nbsp;<?php echo $var->money; ?> &nbsp;<?php echo $var->type_money; ?>

                            </td></tr>
                    </table>
                </div>
                <?php endforeach; ?>
                <hr>
            </div><!-- /card-container -->
        </div><!-- /container -->
    </body>
</html>
